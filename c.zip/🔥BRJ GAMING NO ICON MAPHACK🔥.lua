if os.date("21Y1m29d") >= "yyyymmdd" then
gg.alert("⚠️ This script has expired!") return end
PW = gg.prompt({'Enter Password:'},{[1]=''},{[1]='text'})
if not PW then return
end 
if PW[1] == "" then gg.alert("Enter Password!") os.exit() end
if PW[1] =="YOUR PASSWORD" then 
else
gg.alert("🚫 Password does not match!")
gg.alert("BRJ GAMING SCRIPT")
gg.setVisible(true)
LuaLibraryTool = -1
end


gg.sleep(200)
gg.alert("⚠️ Type Start Information ⚠️")
gg.sleep(200)
gg.toast("⚠️ Type Loading Step ⚠️")
gg.sleep(400)
gg.setVisible(true)
PUBGMH = -1
function HOME() --Home Menu
MENU = gg.choice({
           "MAP HACK",
           "DRONE VIEW",
           "INCREASE GOLD",
           "FREE SKINS",
          "EXIT"
}, nil, "⚠️Type Information e.g date/time your channel name Here")
    if MENU == nil then
  else
    if MENU == 1 then
      MN1()
    end -- Your Channel Name
    if MENU == 2 then
     MN2()
    end -- Your Channel Name
    if MENU == 3 then
     MN3()
    end -- Your Channel Name
     if MENU == 4 then
     MN4()
    end -- Your Channel Name
    if MENU == 5 then
      EXIT()
    end -- Your Channel Name
  end -- Your Channel Name
  PUBGMH = -1
end -- Your Channel Name

--------MENU[1]--------
function MN1()
GL = gg.multiChoice({
           "MAP HACK (ICON)",
           "MAP HACK (NO ICON)",
           "Name",
           "Name",
           "Name",
           "BACK"
}, nil, "⚠️Type Information e.g date/time your channel name Here")
  if GL == nil then
  else
    if GL [1] == true then
      GL1()
    end -- Your Channel Name
    if GL [2] == true then
     GL2()
    end -- Your Channel Name
    if GL [3] == true then
     GL3()
    end -- Your Channel Name
    if GL [4] == true then
     GL4()
    end -- Your Channel Name
    if GL [5] == true then
      GL5()
    end -- Your Channel Name
    if GL [6] == true then
      HOME()
    end -- Your Channel Name
  end -- Your Channel Name
  PUBGMH = -1
end -- Your Channel Name

function GL1() 
--Input Values--
end -- Your Channel Name
 
function GL2()
--Input Values-- 
end -- Your Channel Name
 
function GL3()
--Input Values-- 
end -- Your Channel Name

function GL4() 
--Input Values-- 
end -- Your Channel Name

function GL5()
--Input Values-- 
end -- Your Channel Name

--------MENU[2]--------
function MN2() --Wall & Colour Menu
FK = gg.multiChoice({
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "BACK"
}, nil, "⚠️Type Information e.g date/time your channel name Here")
  if FK == nil then
  else
    if FK [1] == true then
      FK1()
    end -- Your Channel Name
    if FK [2] == true then
     FK2()
    end -- Your Channel Name
    if FK [3] == true then
     FK3()
    end -- Your Channel Name
    if FK [4] == true then
     FK4()
    end -- Your Channel Name
    if FK [5] == true then
      FK5()
    end -- Your Channel Name
    if FK [6] == true then
      HOME()
    end -- Your Channel Name
  end -- Your Channel Name
  PUBGMH = -1
end -- Your Channel Name

function FK1() 
--Input Values--
end -- Your Channel Name
 
function FK2()
--Input Values-- 
end -- Your Channel Name
 
function FK3()
--Input Values-- 
end -- Your Channel Name

function FK4() 
--Input Values-- 
end -- Your Channel Name

function FK5()
--Input Values-- 
end -- Your Channel Name



--------MENU[3]--------

function MN3()
XG = gg.multiChoice({
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "BACK"
}, nil, "⚠️Type Information e.g date/time your channel name Here")
  if XG == nil then
  else
    if XG [1] == true then
      XG1()
    end -- Your Channel Name
    if XG [2] == true then
     XG2()
    end -- Your Channel Name
    if XG [3] == true then
     XG3()
    end -- Your Channel Name
    if XG [4] == true then
     XG4()
    end -- Your Channel Name
    if XG [5] == true then
      XG5()
    end -- Your Channel Name
    if XG [6] == true then
      HOME()
    end -- Your Channel Name
  end -- Your Channel Name
  PUBGMH = -1
end -- Your Channel Name
function XG1() 
--Input Values--
end -- Your Channel Name
 
function XG2()
--Input Values-- 
end -- Your Channel Name
 
function XG3()
--Input Values-- 
end -- Your Channel Name

function XG4() 
--Input Values-- 
end -- Your Channel Name

function XG5()
--Input Values-- 
end -- Your Channel Name



--------MENU[4] --------

function MN4()
QQ = gg.multiChoice({
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "HACK Name",
           "BACK"
}, nil, "⚠️Type Information e.g date/time your channel name Here")
  if QQ == nil then
  else
    if QQ [1] == true then
      QQ1()
    end -- Your Channel Name
    if QQ [2] == true then
     QQ2()
    end -- Your Channel Name
    if QQ [3] == true then
     QQ3()
    end -- Your Channel Name
    if QQ [4] == true then
     QQ4()
    end -- Your Channel Name
    if QQ [5] == true then
      QQ5()
    end -- Your Channel Name
    if QQ [6] == true then
      HOME()
    end -- Your Channel Name
  end -- Your Channel Name
  PUBGMH = -1
end -- Your Channel Name

function QQ1() 
--Input Values--
end -- Your Channel Name
 
function QQ2()
--Input Values-- 
end -- Your Channel Name
 
function QQ3()
--Input Values-- 
end -- Your Channel Name

function QQ4() 
--Input Values-- 
end -- Your Channel Name

function QQ5()
--Input Values-- 
end -- Your Channel Name


function EXIT()
print("⚠️ SCRIPT BY BRJ GAMING SUBSCRIBE ⚠️")
  gg.skipRestoreState()
  gg.setVisible(true)
  os.exit()
end -- Your Channel Name
while true do
  if gg.isVisible(true) then
    PUBGMH = 1
    gg.setVisible(false)
  end -- Your Channel Name
  if PUBGMH == 1 then
    HOME()
  end -- Your Channel Name
end -- Your Channel Name